import java.sql.*;

// javac -cp .;mysql-connector-j-9.1.0.jar JDBCDemo.java  
// java -cp .;mysql-connector-j-9.1.0.jar JDBCDemo   


public class JDBCDemo {
    public static void main(String[] args) {
        // Database connection details
        String url = "jdbc:mysql://localhost:3306/final";
        String user = "root";
        String password = "jade#2004";

        // JDBC objects
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the database!");

            // Create a statement
            statement = connection.createStatement();

            // Execute SELECT query
            String query = "SELECT * FROM doctor";
            resultSet = statement.executeQuery(query);

            // Process the result
            while (resultSet.next()) {
                String data = resultSet.getString("doctor_name");
                System.out.println(data);
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
